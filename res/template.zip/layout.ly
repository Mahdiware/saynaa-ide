return {
  LinearLayout,
  gravity: "center",
  orientation: "vertical",
  {
    TextView,
    text: "Hello SaynaaIDE!",
    textSize: "30sp"
  },
  {
    Button,
    id: "btn",
    text: "Click me",
  }
}